﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiamondShop.Common
{
    // CS5001.cs
    // CS5001 expected when compiled with -target:exe or -target:winexe
    public class Program
    {
        // Uncomment the following line to resolve.
        static void Main() { }
    }
}
